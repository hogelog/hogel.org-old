<?php
scm_eval_file('fib.scm');
scm_eval('(print (fib 30))');
?>
