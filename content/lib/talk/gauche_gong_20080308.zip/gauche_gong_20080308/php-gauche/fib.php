<?php
function fib($x) {
  return $x<3 ? 1 : fib($x-1) + fib($x-2);
}
echo fib(30), "\n";
?>
