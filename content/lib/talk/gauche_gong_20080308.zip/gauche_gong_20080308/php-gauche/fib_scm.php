<?php
scm_eval('
(define (fib x)
  (if (< x 3)
    1 (+ (fib (- x 1)) (fib (- x 2)))))
(print (fib 30))
');
?>
