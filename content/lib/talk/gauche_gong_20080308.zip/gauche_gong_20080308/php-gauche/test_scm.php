<?php
scm_eval_file('fib.scm');

if(isset($_GET['x'])) {
  $x = intval($_GET['x']);
}
else {
  $x = 1;
}
scm_assign('x', $x);

header('Content-type: text/plain');
printf("fib(%d) = %d\n", $x, scm_eval('(fib x)'));
?>
