<?php
scm_assign("int", 30);
scm_eval("(print int)");

scm_assign("float", 3.00);
scm_eval('(print float)');

scm_assign("str", "hage");
scm_eval('(print str)');

scm_assign("bool", true);
scm_eval('(print bool)');

scm_assign("array", array("key"=>30,5=>20));
scm_eval('(print array)');
?>
