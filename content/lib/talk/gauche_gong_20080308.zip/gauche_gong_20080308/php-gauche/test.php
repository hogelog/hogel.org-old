<?php
function fib($x) {
  return $x<3 ? 1 : fib($x-1) + fib($x-2);
}

if(isset($_GET['x'])) {
  $x = intval($_GET['x']);
}
else {
  $x = 1;
}

header('Content-type: text/plain');
printf("fib(%d) = %d\n", $x, fib($x));
?>
