/*
   +----------------------------------------------------------------------+
   | unknown license:                                                      |
   +----------------------------------------------------------------------+
   | Authors: Unknown User <unknown@example.com>                          |
   +----------------------------------------------------------------------+
*/

/* $ Id: $ */ 

#include "php_scm.h"

#if HAVE_SCM

/* {{{ scm_functions[] */
function_entry scm_functions[] = {
	PHP_FE(scm_assign          , scm_assign_arg_info)
	PHP_FE(scm_eval            , scm_eval_arg_info)
	PHP_FE(scm_eval_file       , scm_eval_file_arg_info)
	{ NULL, NULL, NULL }
};
/* }}} */


/* {{{ scm_module_entry
 */
zend_module_entry scm_module_entry = {
	STANDARD_MODULE_HEADER,
	"scm",
	scm_functions,
	PHP_MINIT(scm),     /* Replace with NULL if there is nothing to do at php startup   */ 
	PHP_MSHUTDOWN(scm), /* Replace with NULL if there is nothing to do at php shutdown  */
	PHP_RINIT(scm),     /* Replace with NULL if there is nothing to do at request start */
	PHP_RSHUTDOWN(scm), /* Replace with NULL if there is nothing to do at request end   */
	PHP_MINFO(scm),
	"0.0.1", 
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_SCM
ZEND_GET_MODULE(scm)
#endif


/* {{{ PHP_MINIT_FUNCTION */
PHP_MINIT_FUNCTION(scm)
{

	/* add your stuff here */

	return SUCCESS;
}
/* }}} */


/* {{{ PHP_MSHUTDOWN_FUNCTION */
PHP_MSHUTDOWN_FUNCTION(scm)
{

	/* add your stuff here */

	return SUCCESS;
}
/* }}} */


/* {{{ PHP_RINIT_FUNCTION */
PHP_RINIT_FUNCTION(scm)
{
	/* add your stuff here */

	Scm_Init(GAUCHE_SIGNATURE);
  GaucheEnv = Scm_MakeModule(NULL, FALSE);
  BeginStr = SCM_STRING(SCM_MAKE_STR("(begin "));
  RParenStr = SCM_STRING(SCM_MAKE_STR(")"));

	return SUCCESS;
}
/* }}} */


/* {{{ PHP_RSHUTDOWN_FUNCTION */
PHP_RSHUTDOWN_FUNCTION(scm)
{
	/* add your stuff here */

	return SUCCESS;
}
/* }}} */


/* {{{ PHP_MINFO_FUNCTION */
PHP_MINFO_FUNCTION(scm)
{
	php_info_print_box_start(0);
	php_printf("<p>The unknown extension</p>\n");
	php_printf("<p>Version 0.0.1devel (2008-03-06)</p>\n");
	php_printf("<p><b>Authors:</b></p>\n");
	php_printf("<p>Unknown User &lt;unknown@example.com&gt; (lead)</p>\n");
	php_info_print_box_end();
	/* add your stuff here */

}
/* }}} */


/* {{{ proto void scm_assign(string name, mixed val)
   */
PHP_FUNCTION(scm_assign)
{
	const char * name = NULL;
	int name_len = 0;
	zval * val = NULL;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "sz/", &name, &name_len, &val) == FAILURE) {
		return;
	}

	do {
    ScmObj scm_sym = Scm_Intern(SCM_STRING(SCM_MAKE_STR_COPYING(name)));
    ScmObj scm_val;
    switch(val->type) {
      case IS_LONG:
        scm_val = SCM_MAKE_INT(val->value.lval);
        break;
      case IS_DOUBLE:
        scm_val = SCM_MAKE_INT((int)(val->value.dval));
        break;
      case IS_BOOL:
        scm_val = SCM_MAKE_BOOL(val->value.lval);
        break;
      case IS_STRING:
        scm_val = SCM_MAKE_STR_COPYING(val->value.str.val);
        break;
      case IS_ARRAY:
      case IS_NULL:
      case IS_OBJECT:
      case IS_RESOURCE:
      case IS_CONSTANT:
      case IS_CONSTANT_ARRAY:
        return;
    }
    Scm_Define(SCM_MODULE(GaucheEnv), SCM_SYMBOL(scm_sym), scm_val);
    // SCM_DEFINE(GaucheEnv, name, scm_val);
  } while (0);
}
/* }}} scm_assign */


/* {{{ proto mixed scm_eval(string code)
*/
PHP_FUNCTION(scm_eval)
{
  const char * code = NULL;
  int code_len = 0;

  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &code, &code_len) == FAILURE) {
    return;
  }

  do {
    ScmObj ret;
    ScmString *scm_code = SCM_STRING(SCM_MAKE_STR(code));
    scm_code = SCM_STRING(Scm_StringAppend2(scm_code, RParenStr));
    scm_code = SCM_STRING(Scm_StringAppend2(BeginStr, scm_code));
    ScmObj form = Scm_ReadFromString(scm_code);
    ret = Scm_EvalRec(form, GaucheEnv);
    if(SCM_INTP(ret)) {
      RETURN_LONG(SCM_INT_VALUE(ret));
    }
    else if(SCM_BOOLP(ret)) {
      RETURN_BOOL(SCM_TRUEP(ret));
    }
    else if(SCM_STRINGP(ret)) {
      RETURN_STRING(SCM_STRING_CONST_CSTRING(ret), 1);
    }
    else {
      RETURN_NULL();
    }
  } while (0);
}
/* }}} scm_eval */


/* {{{ proto mixed scm_eval_file(string code)
*/
PHP_FUNCTION(scm_eval_file)
{
  const char * path = NULL;
  int path_len= 0;

  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &path, &path_len) == FAILURE) {
    return;
  }

  do {
    ScmObj scm_port = Scm_OpenFilePort(path, O_RDONLY, SCM_PORT_BUFFER_FULL, 0);
    ScmObj form, ret;
    if(SCM_FALSEP(scm_port)) {
      return;
    }
    while(!SCM_EOFP(form = Scm_Read(scm_port))) {
      ret = Scm_EvalRec(form, GaucheEnv);
    }
    if(SCM_INTP(ret)) {
      RETURN_LONG(SCM_INT_VALUE(ret));
    }
    else if(SCM_BOOLP(ret)) {
      RETURN_BOOL(SCM_TRUEP(ret));
    }
    else if(SCM_STRINGP(ret)) {
      RETURN_STRING(SCM_STRING_CONST_CSTRING(ret), 1);
    }
    else {
      RETURN_NULL();
    }
  } while (0);
}
/* }}} scm_eval_file */

#endif /* HAVE_SCM */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
