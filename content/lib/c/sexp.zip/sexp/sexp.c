#include "sexp.h"

SExp S_Nil = {
  TYPE_PAIR|TYPE_NIL, {(long)NULL}
};

SExp* S_Read_DQuot(FILE *input)
{
  int ch;
  char tmp_buf[MAX_STR_BUF] = "";
  int len = 0;
  SExp *exp;

  while((ch=fgetc(input))!=EOF) {
    switch(ch) {
      case '"':
        tmp_buf[len++] = '\0';
        exp = S_ALLOC();
        TYPE(exp) = TYPE_STRING;
        STR_LENGTH(exp) = len;
        STR_BUF(exp) = ALLOC_STRING(tmp_buf, len);
        return exp;
      default:
        tmp_buf[len++] = ch;
        break;
    }
  }
  return NULL;
}
SExp* S_Read_Num(FILE *input)
{
  int ch;
  long value = 0;
  SExp *exp;

  while((ch=fgetc(input))!=EOF) {
    switch(ch) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
        value = value*10 + ch - '0';
        break;
      default:
        ungetc(ch, input);
        exp = S_ALLOC();
        TYPE(exp) = TYPE_INT;
        INT_VALUE(exp) = value;
        return exp;
    }
  }
  return NULL;
}
SExp* S_Read_Paren(FILE *input)
{
  SExp *exp = S_NIL;
  SExp **iter = &exp;
  int ch;

  while((ch=fgetc(input))!=EOF) {
    switch(ch) {
      case ')':
        *iter = S_NIL;
        return exp;
      case ' ':
      case '\t':
      case '\r':
      case '\n':
        break;
      default:
        ungetc(ch, input);
        *iter = S_ALLOC();
        TYPE(*iter) = TYPE_PAIR;
        PAIR_CAR(*iter) = S_Read(input);
        iter = &PAIR_CDR(*iter);
        break;
    }
  }
  return NULL;
}
SExp* S_Read_Ident(FILE *input)
{
  SExp *exp;
  int ch;
  char tmp_buf[MAX_STR_BUF] = "";
  int len = 0;

  while((ch=fgetc(input))!=EOF) {
    switch(ch) {
      case '"':
      case ' ':
      case '\t':
      case '\r':
      case '\n':
      case '(':
      case ')':
        ungetc(ch, input);
        tmp_buf[len++] = '\0';
        exp = S_ALLOC();
        TYPE(exp) = TYPE_IDENT;
        STR_LENGTH(exp) = len;
        STR_BUF(exp) = ALLOC_STRING(tmp_buf, len);
        return exp;
      default:
        tmp_buf[len++] = ch;
        break;
    }
  }
  return NULL;
}
SExp* S_Read(FILE *input)
{
  int ch;
  while((ch=fgetc(input))!=EOF) {
    switch(ch) {
      case '"':
        return S_Read_DQuot(input);
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
        ungetc(ch, input);
        return S_Read_Num(input);
      case ' ':
      case '\t':
      case '\r':
      case '\n':
        break;
      case '(':
        return S_Read_Paren(input);
      default:
        ungetc(ch, input);
        return S_Read_Ident(input);
    }
  }
  return NULL;
}
int S_Write_Pair(FILE *output, SExp *exp)
{
  fputc('(', output);
  if(!S_NULLP(exp)) {
    while(1) {
      if(S_NULLP(PAIR_CDR(exp))) {
        S_Write(output, PAIR_CAR(exp));
        break;
      }
      else if(!S_PAIRP(PAIR_CDR(exp))) {
        fputs(" . ", output);
        S_Write(output, PAIR_CDR(exp));
        break;
      }
      S_Write(output, PAIR_CAR(exp));
      fputc(' ', output);
      exp = PAIR_CDR(exp);
    }
  }
  fputc(')', output);
  return 0;
}
int S_Write(FILE *output, SExp *exp)
{
  if(S_PAIRP(exp)) {
    S_Write_Pair(output, exp);
  }
  else if(S_INTP(exp)) {
    fprintf(output, "%ld", INT_VALUE(exp));
  }
  else if(S_STRINGP(exp)) {
    fprintf(output, "\"%s\"", STR_BUF(exp));
  }
  else if(S_IDENTP(exp)) {
    fputs(STR_BUF(exp), output);
  }
  return 0;
}
