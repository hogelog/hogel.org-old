#include "sexp.h"
int main(int argc, char *argv[])
{
  SExp *exp;
  while((exp = S_Read(stdin))!=NULL) {
    S_Write(stdout, exp);
    putchar('\n');
  }
  return 0;
}
