#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef union _SValue SValue;
typedef struct _SExp SExp;

#define TYPE_INT     0001
#define TYPE_STRING  0002
#define TYPE_PAIR    0004
#define TYPE_IDENT   0010
#define TYPE_NIL     0020

union _SValue {
  long ival;
  struct {
    int len;
    char *buf;
  } sval;
  struct {
    SExp *car, *cdr;
  } pval;
};
struct _SExp {
  int type;
  SValue value;
};

extern SExp S_Nil;

#define S_NIL (&S_Nil)

#define TYPE(x) ((x)->type)
#define VALUE(x) ((x)->value)
#define INT_VALUE(x) ((VALUE(x)).ival)
#define STR_VALUE(x) ((VALUE(x)).sval)
#define STR_LENGTH(x) ((STR_VALUE(x)).len)
#define STR_BUF(x) ((STR_VALUE(x)).buf)
#define PAIR_VALUE(x) ((VALUE(x)).pval)
#define PAIR_CAR(x) ((PAIR_VALUE(x)).car)
#define PAIR_CDR(x) ((PAIR_VALUE(x)).cdr)

#define S_INTP(x)     ((x)->type&TYPE_INT)
#define S_STRINGP(x)  ((x)->type&TYPE_STRING)
#define S_PAIRP(x)    ((x)->type&TYPE_PAIR)
#define S_IDENTP(x)   ((x)->type&TYPE_IDENT)
#define S_NULLP(x)    ((x)->type&TYPE_NIL)

#define S_ALLOC() ((SExp*)malloc(sizeof(SExp)))

#define ALLOC_STRING(str,len) \
  strncpy((char*)malloc(sizeof(char)*(len)), str, len)

#define MAX_STR_BUF 4096

SExp* S_Read_DQuot(FILE *input);
SExp* S_Read_Num(FILE *input);
SExp* S_Read_Paren(FILE *input);
SExp* S_Read_Ident(FILE *input);
SExp* S_Read(FILE *input);
int S_Write_Pair(FILE *output, SExp *exp);
int S_Write(FILE *output, SExp *exp);
