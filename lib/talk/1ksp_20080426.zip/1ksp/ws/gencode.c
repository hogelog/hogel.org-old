Operation read_A_C(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      RETURN_CODE(input, ch, "read_A_C", DUP);
    case B:
      RETURN_CODE(input, ch, "read_A_C", SWAP);
    case C:
      RETURN_CODE(input, ch, "read_A_C", DISCARD);
    case EOF:
      RETURN_CODE(input, ch, "read_A_C", ERROR);
  }
  return read_A_C(input);
}
Operation read_A_B(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      RETURN_CODE(input, ch, "read_A_B", REF);
    case B:
      RETURN_CODE(input, ch, "read_A_B", ERROR);
    case C:
      RETURN_CODE(input, ch, "read_A_B", SLIDE);
    case EOF:
      RETURN_CODE(input, ch, "read_A_B", ERROR);
  }
  return read_A_B(input);
}
Operation read_A(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      RETURN_CODE(input, ch, "read_A", PUSH);
    case B:
      return read_A_B(input);
    case C:
      return read_A_C(input);
    case EOF:
      RETURN_CODE(input, ch, "read_A", ERROR);
  }
  return read_A(input);
}
Operation read_BA_A(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      RETURN_CODE(input, ch, "read_BA_A", PLUS);
    case B:
      RETURN_CODE(input, ch, "read_BA_A", MINUS);
    case C:
      RETURN_CODE(input, ch, "read_BA_A", TIMES);
    case EOF:
      RETURN_CODE(input, ch, "read_BA_A", ERROR);
  }
  return read_BA_A(input);
}
Operation read_BA_B(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      RETURN_CODE(input, ch, "read_BA_B", DIVIDE);
    case B:
      RETURN_CODE(input, ch, "read_BA_B", MODULO);
    case C:
      RETURN_CODE(input, ch, "read_BA_B", ERROR);
    case EOF:
      RETURN_CODE(input, ch, "read_BA_B", ERROR);
  }
  return read_BA_B(input);
}
Operation read_BA(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      return read_BA_A(input);
    case B:
      return read_BA_B(input);
    case C:
      RETURN_CODE(input, ch, "read_BA", ERROR);
    case EOF:
      RETURN_CODE(input, ch, "read_BA", ERROR);
  }
  return read_BA(input);
}
Operation read_BB(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      RETURN_CODE(input, ch, "read_BB", STORE);
    case B:
      RETURN_CODE(input, ch, "read_BB", RETRIEVE);
    case C:
      RETURN_CODE(input, ch, "read_BB", ERROR);
    case EOF:
      RETURN_CODE(input, ch, "read_BB", ERROR);
  }
  return read_BB(input);
}
Operation read_C_A(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      RETURN_CODE(input, ch, "read_C_A", LABEL);
    case B:
      RETURN_CODE(input, ch, "read_C_A", CALL);
    case C:
      RETURN_CODE(input, ch, "read_C_A", JUMP);
    case EOF:
      RETURN_CODE(input, ch, "read_C_A", ERROR);
  }
  return read_C_A(input);
}
Operation read_C_B(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      RETURN_CODE(input, ch, "read_C_B", IZ_JUMP);
    case B:
      RETURN_CODE(input, ch, "read_C_B", IN_JUMP);
    case C:
      RETURN_CODE(input, ch, "read_C_B", RETURN);
    case EOF:
      RETURN_CODE(input, ch, "read_C_B", ERROR);
  }
  return read_C_B(input);
}
Operation read_C_C(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      RETURN_CODE(input, ch, "read_C_C", ERROR);
    case B:
      RETURN_CODE(input, ch, "read_C_C", ERROR);
    case C:
      RETURN_CODE(input, ch, "read_C_C", END);
    case EOF:
      RETURN_CODE(input, ch, "read_C_C", ERROR);
  }
  return read_C_C(input);
}
Operation read_C(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      return read_C_A(input);
    case B:
      return read_C_B(input);
    case C:
      return read_C_C(input);
    case EOF:
      RETURN_CODE(input, ch, "read_C", ERROR);
  }
  return read_C(input);
}
Operation read_BC_A(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      RETURN_CODE(input, ch, "read_BC_A", OUTPUTC);
    case B:
      RETURN_CODE(input, ch, "read_BC_A", OUTPUTN);
    case C:
      RETURN_CODE(input, ch, "read_BC_A", ERROR);
    case EOF:
      RETURN_CODE(input, ch, "read_BC_A", ERROR);
  }
  return read_BC_A(input);
}
Operation read_BC_B(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      RETURN_CODE(input, ch, "read_BC_B", READC);
    case B:
      RETURN_CODE(input, ch, "read_BC_B", READN);
    case C:
      RETURN_CODE(input, ch, "read_BC_B", ERROR);
    case EOF:
      RETURN_CODE(input, ch, "read_BC_B", ERROR);
  }
  return read_BC_B(input);
}
Operation read_BC(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      return read_BC_A(input);
    case B:
      return read_BC_B(input);
    case C:
      RETURN_CODE(input, ch, "read_BC", ERROR);
    case EOF:
      RETURN_CODE(input, ch, "read_BC", ERROR);
  }
  return read_BC(input);
}
Operation read_B(FILE* input) {
  int ch = getc(input);
  switch(ch) {
    case A:
      return read_BA(input);
    case B:
      return read_BB(input);
    case C:
      return read_BC(input);
    case EOF:
      RETURN_CODE(input, ch, "read_B", ERROR);
  }
  return read_B(input);
}
